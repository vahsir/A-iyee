Skip to main content  [ LinkedIn ](/?trk=public_profile_nav-header-logo)

  * [ Top Content  ](https://www.linkedin.com/top-content?trk=public_profile_guest_nav_menu_topContent)
  * [ People  ](https://www.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
  * [ Learning  ](https://www.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
  * [ Jobs  ](https://www.linkedin.com/jobs/jobs-in-mountain-view-ca?trk=public_profile_guest_nav_menu_jobs)
  * [ Games  ](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)



[ Sign in ](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fin%2Elinkedin%2Ecom%2Fin%2Fbankarishav&fromSignIn=true&trk=public_profile_nav-header-signin) [ Join now  ](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&session_redirect=https%3A%2F%2Fin.linkedin.com%2Fin%2Fbankarishav&trk=public_profile_nav-header-join) [ ](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fin%2Elinkedin%2Ecom%2Fin%2Fbankarishav&fromSignIn=true&trk=public_profile_nav-header-signin)

##  Sign in to view Rishav’s full profile 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

#  Rishav B. 

##  Sign in to view Rishav’s full profile 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

### 

Bengaluru, Karnataka, India Contact Info 

##  Sign in to view Rishav’s full profile 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

1K followers  500+ connections 

#### 

See your mutual connections

##  View mutual connections with Rishav 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_mutual-connections_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

[ Join to view profile ](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_top-card-primary-button-join-to-view-profile)

Message 

##  Sign in to view Rishav’s full profile 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_top-card_secondary-cta-modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

[ Sprinklr  ](https://www.linkedin.com/company/sprinklr?trk=public_profile_topcard-current-company)

[ PES College of Engineering - India  ](https://in.linkedin.com/school/pes-college-of-engineering---india/?trk=public_profile_topcard-school)

  * [ Report this profile ](/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fin.linkedin.com%2Fin%2Fbankarishav&trk=public_profile_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=PROFILE&_f=guest-reporting)



##  About 

Computer Science Engineer from PESIT, Bangalore 

see more 

##  Welcome back 

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_sign-in-modal_forgot_password) Sign in 

or 

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=public_profile_sign-in-modal_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=public_profile_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=public_profile_sign-in-modal_auth-button_cookie-policy). 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_sign-in-modal_join-link)

##  Activity 

###  1K followers 

  * Comments 
  * Reactions 



Rishav B. commented on a post  1y 

Congrats Abhigyan! All the best for your future!! 🎉 

[ ](https://www.linkedin.com/posts/abhigyan-manasvi-8505541a2_iimvisakhapatnam-mbajourney-gratitude-activity-7342455142258044928-gkz6)

No more previous content 

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fpavitar_were-paying-12x-for-frontier-models-to-get-activity-7470387768284569600--5Br&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/pavitar_were-paying-12x-for-frontier-models-to-get-activity-7470387768284569600--5Br)

[ Pavitar Singh  ](https://www.linkedin.com/in/pavitar)

###  Pavitar Singh 

1w 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/pavitar_were-paying-12x-for-frontier-models-to-get-activity-7470387768284569600--5Br)

We're paying 12x for frontier models to get sub-10% accuracy improvements. Read that again. If a vendor told you: "Our premium tier costs 12x more and is 8% better," you'd laugh them out of the room. But in AI, we've normalized it. Here's what I see in real enterprise deployments: → 80% of tasks are classification, extraction, summarization, routing. A model that costs 1/12th the price handles these at near-identical quality. → The accuracy delta on benchmarks rarely shows up in YOUR workload. MMLU scores don't predict how well a model extracts invoice line items. → At scale, the math is brutal. 100B tokens/day at frontier pricing vs. right-sized models is the difference between an AI budget and an AI line item. The frontier model tax is real. Most companies are paying it out of inertia, not analysis. The question isn't "which model is best?" It's "which model is best for THIS task at THIS price?" Most teams have never run that analysis. The ones who have are spending 70% less. 

`` ``

[ 326  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 19 Comments ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Faviral065_cloudengineering-sre-devops-activity-7467162002478784512-5ZYy&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/aviral065_cloudengineering-sre-devops-activity-7467162002478784512-5ZYy)

[ Aviral Agarwal  ](https://in.linkedin.com/in/aviral065)

###  Aviral Agarwal 

3w 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/aviral065_cloudengineering-sre-devops-activity-7467162002478784512-5ZYy)

Excited to share that I've been promoted to Senior Cloud Engineer at [Sprinklr](https://www.linkedin.com/company/sprinklr?trk=public_profile__reactions-text)! Grateful for the opportunities, challenges, and incredible people who have helped me grow along the way. From cloud infrastructure and Kubernetes to automation and reliability engineering, the journey has been filled with continuous learning. Looking forward to taking on bigger challenges, building impactful solutions, and continuing to grow as an engineer. [#CloudEngineering](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fcloudengineering&trk=public_profile__reactions-text) [#SRE](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fsre&trk=public_profile__reactions-text) [#DevOps](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fdevops&trk=public_profile__reactions-text) [#Kubernetes](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fkubernetes&trk=public_profile__reactions-text) [#AWS](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Faws&trk=public_profile__reactions-text) [#CareerGrowth](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fcareergrowth&trk=public_profile__reactions-text)

`` ``

[ 162  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 47 Comments ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fpavitar_cfos-dont-fund-activity-they-fund-outcomes-activity-7472522376342274048-Jkm1&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/pavitar_cfos-dont-fund-activity-they-fund-outcomes-activity-7472522376342274048-Jkm1)

[ Pavitar Singh  ](https://www.linkedin.com/in/pavitar)

###  Pavitar Singh 

1w 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/pavitar_cfos-dont-fund-activity-they-fund-outcomes-activity-7472522376342274048-Jkm1)

CFOs don't fund activity. They fund outcomes. "We processed 40B tokens last month" means nothing to them. These do: → 12,000 support tickets resolved at $0.31 each, down from $4.20 with a human in the loop → $20.1M in invoices reconciled with zero manual touches → sales cycle cut by 9 days because every lead got researched and routed in minutes, not days → a compliance review that took 3 analysts a week now done overnight That's what gets the next budget approved. The shift is from cost-per-token to cost-per-outcome. It means attributing every agent run to the thing it changed in the business — the ticket, the invoice, the deal, the report — which is exactly the context most AI stacks throw away. The AI cost conversation is moving out of engineering and into finance. The teams that can speak that language win. The ones still bragging about token volume are about to get a very uncomfortable question. What did the burn actually buy? 

`` ``

[ 249  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 6 Comments ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Flaxmi-magennawar-67104986_mindset-personalgrowth-selfdevelopment-activity-7472502383231750144-IEWI&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/laxmi-magennawar-67104986_mindset-personalgrowth-selfdevelopment-activity-7472502383231750144-IEWI)

[ Laxmi Magennawar  ](https://in.linkedin.com/in/laxmi-magennawar-67104986)

###  Laxmi Magennawar 

1w 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/laxmi-magennawar-67104986_mindset-personalgrowth-selfdevelopment-activity-7472502383231750144-IEWI)

𝗪𝗶𝗹𝗹𝗽𝗼𝘄𝗲𝗿 𝗶𝘀𝗻'𝘁 𝘀𝗼𝗺𝗲𝘁𝗵𝗶𝗻𝗴 𝘄𝗲'𝗿𝗲 𝗯𝗼𝗿𝗻 𝘄������𝘁𝗵. 𝗜𝘁'𝘀 𝘀𝗼𝗺𝗲𝘁𝗵𝗶𝗻𝗴 𝘁𝗵𝗮𝘁 𝗴𝗲𝘁𝘀 𝗯𝘂𝗶𝗹𝘁. Every small commitment followed through on quietly adds up.  • Waking up at the same time.  • Finishing what was started.  • Showing up even when it felt unnecessary. Not because any single action changes everything. But because over time those actions build something harder to see but easier to feel. Psychologists call this self-efficacy - the belief in one's own ability to follow through. The stronger it gets, the less effort the bigger decisions seem to take. That evidence compounds. Slowly. Then suddenly. [#Mindset](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fmindset&trk=public_profile__reactions-text) [#PersonalGrowth](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fpersonalgrowth&trk=public_profile__reactions-text) [#SelfDevelopment](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fselfdevelopment&trk=public_profile__reactions-text) [#Discipline](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fdiscipline&trk=public_profile__reactions-text) [#Habits](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fhabits&trk=public_profile__reactions-text)

[ public_profile__reactions  ](https://www.linkedin.com/posts/laxmi-magennawar-67104986_mindset-personalgrowth-selfdevelopment-activity-7472502383231750144-IEWI)

`` ``

[ 11  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 1 Comment ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fpuneet-ag_after-an-incredible-45-years-at-plivo-activity-7467940749762949120-3WJW&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/puneet-ag_after-an-incredible-45-years-at-plivo-activity-7467940749762949120-3WJW)

[ Puneet Agrawal  ](https://in.linkedin.com/in/puneet-ag)

###  Puneet Agrawal 

2w 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/puneet-ag_after-an-incredible-45-years-at-plivo-activity-7467940749762949120-3WJW)

After an incredible 4.5 years at [Plivo](https://www.linkedin.com/company/plivo-inc?trk=public_profile__reactions-text) , it’s time for a new chapter. My journey at Plivo has been full of learning, growth, challenges, and amazing memories. I had the opportunity to work with great people, build meaningful things, and grow both personally and professionally. A special thanks to [Manish Kaushik](https://in.linkedin.com/in/manish-kaushik-6a587a14?trk=public_profile__reactions-text) for the guidance, support, and trust throughout this journey. I’m excited to share that I’ve joined [Bolna (YC F25)](https://www.linkedin.com/company/bolna-ai?trk=public_profile__reactions-text) as a Backend Engineer. It has already been over a month here, and it truly feels like a fresh start. The energy, pace, and talented minds around me have made this transition really exciting. I’ve already shipped a few things, learned a lot, and I’m looking forward to building much more. A big thank you to [Prateek Sachan](https://www.linkedin.com/in/prateek-sachan?trk=public_profile__reactions-text) and [Maitreya Wagh](https://www.linkedin.com/in/maitreya-wagh?trk=public_profile__reactions-text) for the opportunity and for trusting me with this role. Excited for what lies ahead! 

`` ``

[ 227  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 35 Comments ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  liked this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fvishal-singhal-09b07946_if-youre-using-cursor-this-ones-for-you-activity-7455650995373760512-AXb5&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. liked this  ](https://www.linkedin.com/posts/vishal-singhal-09b07946_if-youre-using-cursor-this-ones-for-you-activity-7455650995373760512-AXb5)

[ Vishal Singhal  ](https://in.linkedin.com/in/vishal-singhal-09b07946)

###  Vishal Singhal 

1mo 

[ Rishav B. liked this  ](https://www.linkedin.com/posts/vishal-singhal-09b07946_if-youre-using-cursor-this-ones-for-you-activity-7455650995373760512-AXb5)

If you're using [Cursor](https://www.linkedin.com/company/cursorai?trk=public_profile__reactions-text), this one's for you. [Harness](https://www.linkedin.com/company/harnessinc?trk=public_profile__reactions-text) just shipped a plugin that lets you manage your entire delivery workflow — pipelines, deployments, governance — without ever leaving your editor. Ask it to list your pipelines, trigger a build, or check for vulnerabilities, all through natural language in Cursor chat. Everything you need to go from code to production, right where you already work. 🚀 Install the plugin today 👉 [https://lnkd.in/g9UMsmGd](https://lnkd.in/g9UMsmGd?trk=public_profile__reactions-text)

[ public_profile__reactions  ](https://www.linkedin.com/posts/vishal-singhal-09b07946_if-youre-using-cursor-this-ones-for-you-activity-7455650995373760512-AXb5)

`` ``

[ 43  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` ``

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  liked this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fabhaybansal_improving-performance-by-30-using-aws-graviton4-activity-7455581402177146880-KWRs&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Abhay B.  ](https://sg.linkedin.com/in/abhaybansal)

###  Abhay B. 

1mo 

[ Rishav B. liked this  ](https://www.linkedin.com/posts/abhaybansal_improving-performance-by-30-using-aws-graviton4-activity-7455581402177146880-KWRs)

Excited to see Sprinklr’s AWS Graviton4 journey featured as an AWS case study. This has been an important part of our broader effort to build a more performant, resilient, and cost-efficient infrastructure platform at enterprise scale. The results are a strong reflection of the engineering depth across teams at Sprinklr and the close partnership with AWS. A big thank you to [Gaurav Garg](https://in.linkedin.com/in/gargaura?trk=public_profile__reactions-text) and the Amazon team for partnering with us through this journey and helping make this possible. Proud of the Sprinklr engineering teams who drove this with focus and ownership. 

[ Nitin Goyal  ](https://sg.linkedin.com/in/nitin2goyal)

###  Nitin Goyal 

1mo 

[ Rishav B. liked this  ](https://www.linkedin.com/posts/abhaybansal_improving-performance-by-30-using-aws-graviton4-activity-7455581402177146880-KWRs)

Excited to see Sprinklr’s AWS Graviton4 journey featured as an AWS case study. At Sprinklr, we have been focused on building a more performant, resilient, and cost-efficient infrastructure platform at enterprise scale. Graviton4 has been an important part of that journey, helping us improve performance across microservices and databases while reducing infrastructure footprint. Proud of the teams across Sprinklr and AWS who partnered on this work. Full case study: [https://lnkd.in/gEQwHv9V](https://lnkd.in/gEQwHv9V?trk=public_profile__reactions-text) [#PlatformEngineering](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fplatformengineering&trk=public_profile__reactions-text) [#Sprinklr](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fsprinklr&trk=public_profile__reactions-text)

`` ``

[ 25  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 1 Comment ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_comment-cta) `` ``

    * Copy
    * LinkedIn
    * Facebook
    * X

  * [ Rishav B.  reacted on this  ](https://in.linkedin.com/in/bankarishav?trk=public_profile__reactions_face-pile-cta)

    * [ Report this post ](/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fnitin2goyal_improving-performance-by-30-using-aws-graviton4-activity-7455217594590158848-AYlg&trk=public_profile__reactions_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/nitin2goyal_improving-performance-by-30-using-aws-graviton4-activity-7455217594590158848-AYlg)

[ Nitin Goyal  ](https://sg.linkedin.com/in/nitin2goyal)

###  Nitin Goyal 

1mo 

[ Rishav B. reacted on this  ](https://www.linkedin.com/posts/nitin2goyal_improving-performance-by-30-using-aws-graviton4-activity-7455217594590158848-AYlg)

Excited to see Sprinklr’s AWS Graviton4 journey featured as an AWS case study. At Sprinklr, we have been focused on building a more performant, resilient, and cost-efficient infrastructure platform at enterprise scale. Graviton4 has been an important part of that journey, helping us improve performance across microservices and databases while reducing infrastructure footprint. Proud of the teams across Sprinklr and AWS who partnered on this work. Full case study: [https://lnkd.in/gEQwHv9V](https://lnkd.in/gEQwHv9V?trk=public_profile__reactions-text) [#PlatformEngineering](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fplatformengineering&trk=public_profile__reactions-text) [#Sprinklr](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fsprinklr&trk=public_profile__reactions-text)

`` ``

[ 99  ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-reactions) `` `` `` `` `` `` `` [ 1 Comment ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_social-actions-comments)

``

[ ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile__reactions_like-cta)

`` ``

    * Copy
    * LinkedIn
    * Facebook
    * X




No more next content 

Slide to item 1 

``

[ See all activities ](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fin%2Fbankarishav%2Frecent-activity%2F&trk=public_profile)

##  Experience & Education 

  * ###  Sprinklr 

#### 

****** **** 




  * ###  ******* ** ********* **** **** 

#### 

****** 

  * ###  *** ******* ** *********** * ***** 

#### 

******** ** *********** * ** undefined undefined 

2016 \- 2020

  * ###  ****** ****** ****** 

#### 

******* undefined 

2008 \- 2015




## View Rishav’s full experience

### See their title, tenure and more.

Sign in 

##  Welcome back 

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_sign-in-modal_forgot_password) Sign in 

or 

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=public_profile_sign-in-modal_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=public_profile_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=public_profile_sign-in-modal_auth-button_cookie-policy). 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_sign-in-modal_join-link)

or 

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=public_profile_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=public_profile_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=public_profile_auth-button_cookie-policy). 

##  Licenses & Certifications 

  * [ ](https://in.linkedin.com/company/nptel?trk=public_profile_profile-section-card_image-click)

###  [ Deep Learning ](http://nptel.ac.in/noc/social_cert/noc18-cs41/NPTEL18CS41S211516161810084470.jpg?trk=public_profile_certification-title)

####  [ NPTEL ](https://in.linkedin.com/company/nptel?trk=public_profile_profile-section-card_subtitle-click)

Issued Aug 2018

Credential ID NPTEL18CS41S21151616 

[ See credential  ](http://nptel.ac.in/noc/social_cert/noc18-cs41/NPTEL18CS41S211516161810084470.jpg?trk=public_profile_see-credential)

  * [ ](https://in.linkedin.com/company/nptel?trk=public_profile_profile-section-card_image-click)

###  [ Programming in C++ ](http://nptel.ac.in/noc/social_cert/noc17-cs24/NPTEL17CS24S2190518171008825.jpg?trk=public_profile_certification-title)

####  [ NPTEL ](https://in.linkedin.com/company/nptel?trk=public_profile_profile-section-card_subtitle-click)

Issued Jul 2017

Credential ID NPTEL17CS24S2190518 

[ See credential  ](http://nptel.ac.in/noc/social_cert/noc17-cs24/NPTEL17CS24S2190518171008825.jpg?trk=public_profile_see-credential)




##  Volunteer Experience 

  * [ ](https://ca.linkedin.com/company/icacci?trk=public_profile_volunteering-position_profile-section-card_image-click)

###  Session Conductor Volunteer 

####  [ ICACCI ](https://ca.linkedin.com/company/icacci?trk=public_profile_volunteering-position_profile-section-card_subtitle-click)

Sep 2018 \- Sep 2018 1 month

Education 

7th International Conference held at PESIT. 




##  Courses 

  * ###  Deep Learning 

#### -

  * ###  Programming in C++ 

####  https://onlinecourses.np 

  * ###  Web Development 

#### -




##  Projects 

  * ###  Cure to Diabetic Retinopathy 

####  Sep 2018 \- Oct 2018

Developed an application for people suffering from diabetics as they have a chance of suffering from diabetic retinopathy i.e, with the help of image of cornea, detect if the person is suffering from the disease using deep learning image classification model[CNN]. 




##  Recommendations received 

  * ### [ Laxmi Magennawar  "It is rare to come across someone who combines deep technical expertise, strong ownership, and a relentless commitment to team success as effectively as Rishav. He consistently demonstrated strong ownership, taking on challenging tasks without hesitation and delivering high-quality outcomes with speed and precision. His deep technical expertise helped drive several infrastructure and Infrastructure as Code (IaC) optimizations, improving the efficiency and reliability of our platform. Beyond his technical contributions, he showed strong leadership through knowledge sharing, mentoring, and collaboration. He was also someone we could always rely on during critical incidents and escalations. His technical excellence, initiative, and commitment to the team’s success make him a valuable asset to any organization. I highly recommend him and am confident he will excel in any role he takes on." ](https://in.linkedin.com/in/laxmi-magennawar-67104986?trk=public_profile_recommendations)

  * ### [ Shree Ahuja  "I had the privilege of working with Rishav right from the beginning of my journey at Sprinklr, starting with my internship — and he has been a mentor to me ever since. From day one, he consistently created an environment where learning, asking questions, and taking ownership felt natural and supported. Rishav is exceptionally talented and one of the most knowledgeable people I’ve come across, especially when it comes to Elasticsearch — his depth of understanding and ability to troubleshoot complex issues is truly impressive. He’s meticulous when it comes to Site Reliability Engineering (SRE), always ensuring systems are efficient, resilient, and well-monitored. His attention to detail and commitment to quality made a huge difference to the team's overall performance. As a manager, he always had our backs. Whether it was navigating tough challenges or tight timelines, he remained calm and composed, guiding us through with clarity. He stood out for his empathy — always understanding when I felt overloaded and stepping in to support wherever needed. I’m especially grateful for how approachable he was; no question was ever too small or silly, and his patience made a big difference in my growth. Working with Rishav has been truly impactful in shaping my professional mindset, and I carry forward a lot of what I learned from him, any team would be lucky to have a leader and expert like him." ](https://in.linkedin.com/in/shree112?trk=public_profile_recommendations)




2 people have recommended Rishav 

[ Join now to view ](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_recommendations)

##  View Rishav’s full profile 

  * See who you know in common 
  * Get introduced 
  * Contact Rishav directly 

[ Join to view full profile ](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_bottom-cta-banner)

##  Other similar profiles 

  * [ Pranali Ozarkar  ](https://in.linkedin.com/in/pranali-ozarkar)

###  Pranali Ozarkar 

Globant 

2K followers

Pune Division

[ View Profile ](https://in.linkedin.com/in/pranali-ozarkar?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Deep savani  ](https://in.linkedin.com/in/deep-savani-70131015b)

###  Deep savani 

Google 

3K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/deep-savani-70131015b?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Achal Sharma  ](https://in.linkedin.com/in/achal-sharma-13b45614a)

###  Achal Sharma 

DoremonLabs 

2K followers

Gurugram

[ View Profile ](https://in.linkedin.com/in/achal-sharma-13b45614a?trk=public_profile_browsemap_browse-map_connect-button)

  * [ oshien jindal  ](https://in.linkedin.com/in/oshien-jindal-6a314011b)

###  oshien jindal 

Arcesium 

2K followers

Sangrur

[ View Profile ](https://in.linkedin.com/in/oshien-jindal-6a314011b?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Nikhil Agrawal  ](https://in.linkedin.com/in/nikhil-agrawal-84467a180)

###  Nikhil Agrawal 

Uber AI Solutions 

3K followers

Rajasthan, India

[ View Profile ](https://in.linkedin.com/in/nikhil-agrawal-84467a180?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Shishir Khandelwal  ](https://in.linkedin.com/in/shishirkhandelwal)

###  Shishir Khandelwal 

PW (PhysicsWallah) 

21K followers

India

[ View Profile ](https://in.linkedin.com/in/shishirkhandelwal?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Gaurav Gupta  ](https://in.linkedin.com/in/gauravgupta98)

###  Gaurav Gupta 

Zepto 

2K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/gauravgupta98?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Md Danish Anwar  ](https://in.linkedin.com/in/iammda23)

###  Md Danish Anwar 

Texas Instruments 

2K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/iammda23?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Shubham Saini  ](https://in.linkedin.com/in/frontendshubham)

###  Shubham Saini 

Nagarro 

3K followers

Gurgaon

[ View Profile ](https://in.linkedin.com/in/frontendshubham?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Avnish Sharma  ](https://in.linkedin.com/in/avnish-sharma-nitk)

###  Avnish Sharma 

iManage 

2K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/avnish-sharma-nitk?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Zaid Naikwadi  ](https://in.linkedin.com/in/zaid-naikwadi-8a7588162)

###  Zaid Naikwadi 

TomTom 

2K followers

Pune Division

[ View Profile ](https://in.linkedin.com/in/zaid-naikwadi-8a7588162?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Himanshu Vishwakarma  ](https://in.linkedin.com/in/himanshuvishwakarma)

###  Himanshu Vishwakarma 

Coupang 

4K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/himanshuvishwakarma?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Nikhil Gupta  ](https://in.linkedin.com/in/nikhilgupta04)

###  Nikhil Gupta 

American Express Global Business Travel 

8K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/nikhilgupta04?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Nilesh Bhadana  ](https://in.linkedin.com/in/nileshbhadana)

###  Nilesh Bhadana 

Blinkit 

2K followers

Rajasthan, India

[ View Profile ](https://in.linkedin.com/in/nileshbhadana?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Pushpender S.  ](https://in.linkedin.com/in/pushpendersofficial)

###  Pushpender S. 

EPAM Systems 

3K followers

Gurugram

[ View Profile ](https://in.linkedin.com/in/pushpendersofficial?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Vaidehi Kher  ](https://in.linkedin.com/in/vaidehikher)

###  Vaidehi Kher 

Microsoft 

6K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/vaidehikher?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Manisha Agarwal  ](https://in.linkedin.com/in/agarwal-manisha)

###  Manisha Agarwal 

Salesforce 

10K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/agarwal-manisha?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Umang Upadhyay  ](https://in.linkedin.com/in/umang-upadhyay)

###  Umang Upadhyay 

Google 

2K followers

Bangalore Urban

[ View Profile ](https://in.linkedin.com/in/umang-upadhyay?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Shubham Pratap Singh  ](https://in.linkedin.com/in/shubhampratapsingh)

###  Shubham Pratap Singh 

Lumenore 

3K followers

Bhopal

[ View Profile ](https://in.linkedin.com/in/shubhampratapsingh?trk=public_profile_browsemap_browse-map_connect-button)

  * [ Amanpreet Kaur  ](https://in.linkedin.com/in/amanpreetkaur00)

###  Amanpreet Kaur 

MoEngage 

3K followers

Bengaluru

[ View Profile ](https://in.linkedin.com/in/amanpreetkaur00?trk=public_profile_browsemap_browse-map_connect-button)


Show more profiles  Show fewer profiles 

##  Explore more posts 

  * [ Alyssum Global Services  5K followers ](https://in.linkedin.com/company/alyssum-global-services?trk=public_profile_relatedPosts_face-pile-cta) ### [ We’ve talked about the what and the how. But here’s the real question every enterprise asks: 👉 Will it scale on cluster architecture? At KubeCon Hyderabad 2025, Amit Kalash takes us inside Dragonfly’s cluster-ready design—built to handle distributed workloads without compromising speed or simplicity. Because in today’s world, performance is only as good as your ability to scale. Stay tuned for the final chapter. #KubeCon2025 #DragonflyDB #ClusterArchitecture #InMemoryData #Scalability #EnterpriseTech #OpenSource #DistributedSystems #TechInnovation #alyssumglobal  `` `` 7  `` `` `` `` `` `` `` ](https://www.linkedin.com/posts/alyssum-global-services_kubecon2025-dragonflydb-clusterarchitecture-activity-7368228959198605315-d-FK?trk=public_profile_relatedPosts)

  * [ PGConf India  3K followers ](https://in.linkedin.com/company/pgconf-india?trk=public_profile_relatedPosts_face-pile-cta) ### [ Join Vinay Kumar Paladi and Sashikanta Pattanaik from AWS to master the PostgreSQL tools and performance hacks that save hours of manual work. From deep-dive tuning to the cutting-edge features of PostgreSQL 18, they’re covering everything DBAs and developers need to thrive in modern cloud environments. #PostgreSQL #DatabaseAdministration #PostgreSQL18  `` `` 19  `` `` `` `` `` `` `` 1 Comment  ](https://www.linkedin.com/posts/pgconf-india_postgresql-databaseadministration-postgresql18-activity-7435138725317173248-ZYFR?trk=public_profile_relatedPosts)

  * [ AWS User Group Vadodara  7K followers ](https://in.linkedin.com/company/awsugbdq?trk=public_profile_relatedPosts_face-pile-cta) ### [ Abhishek Wagh, AWS Community Builder & Sr. Platform Engineer Quantiphi, shares insights on “Seamless Kubernetes Migration,” using AWS KMF to move from GKE to EKS with efficiency. #ACD2025 #AWSVAD2025  `` `` 75  `` `` `` `` `` `` `` 4 Comments  ](https://www.linkedin.com/posts/awsugbdq_acd2025-awsvad2025-activity-7372566014108094464-Nign?trk=public_profile_relatedPosts)

  * [ OpenSource DB  2K followers ](https://in.linkedin.com/company/opensource-db?trk=public_profile_relatedPosts_face-pile-cta) ### [ Excited to share the sixth blog of our journey to PGConf India "Oracle to PostgreSQL Migration: Testing and validation of CDC with Debezium & Apache Kafka" In this blog, Lokesh Mandyam walks through the testing and validation phase of an Oracle-to-PostgreSQL CDC migration, demonstrating how to verify Debezium and Apache Kafka pipeline health, validate DML replication, monitor lag, and ensure end-to-end synchronization before production cutover. Read the blog here: https://lnkd.in/gGd_kii3 Prepared. Postgres-Powered. PGConf India-Bound. See you at #PGConfIndia #PostgreSQL #PGConfIndia #BangaloreTech #PostgresCommunity #OpenSource #TechEvents #OpenSourceDB  `` `` 11  `` `` `` `` `` `` `` ](https://www.linkedin.com/posts/opensource-db_oracle-to-postgresql-migration-testing-and-activity-7429795380537741312-ISWm?trk=public_profile_relatedPosts)

  * [ Prague PostgreSQL Developer Day  486 followers ](https://cz.linkedin.com/company/prague-postgresql-developer-day?trk=public_profile_relatedPosts_face-pile-cta) ### [ #throwback Autovacuum tuning meets cloud cost reality 💸☁️ Mayuresh B. Bagayatkar shows how to balance PostgreSQL performance, maintenance, and FinOps across AWS, GCP, and Azure. Learn real-world tricks to tune autovacuum without overspending. ▶️ Watch now! https://lnkd.in/dFS8g6pT #PostgreSQL #PGDay #PPDD #Autovacuum #FinOps  `` `` 3  `` `` `` `` `` `` `` ](https://www.linkedin.com/posts/prague-postgresql-developer-day_throwback-postgresql-pgday-activity-7419726189801463808-yb91?trk=public_profile_relatedPosts)


Show more posts  Show fewer posts 

##  Explore top content on LinkedIn 

Find curated posts and insights for relevant topics all in one place. 

[ View top content ](https://www.linkedin.com/top-content/)

##  Add new skills with these courses 

  * [ 2h 19m Advanced Data Engineering with Snowflake  ](https://www.linkedin.com/learning/advanced-data-engineering-with-snowflake?trk=public_profile_recommended-course)
  * [ 52m Enterprise AI Solutions with AWS: Amazon Q Business, Bedrock Knowledge Bases, and SageMaker MLOps  ](https://www.linkedin.com/learning/enterprise-ai-solutions-with-aws-amazon-q-business-bedrock-knowledge-bases-and-sagemaker-mlops?trk=public_profile_recommended-course)
  * [ 2h 37m Azure DevOps for Beginners  ](https://www.linkedin.com/learning/azure-devops-for-beginners-23145679?trk=public_profile_recommended-course)

[ See all courses ](https://www.linkedin.com/learning/?trk=seo_pp_d_cymbii_more_m015_learning)

  * LinkedIn (C) 2026
  * [ About ](https://about.linkedin.com?trk=public_profile_v3_desktop_footer-about)
  * [ Accessibility ](https://www.linkedin.com/accessibility?trk=public_profile_v3_desktop_footer-accessibility)
  * [ User Agreement ](https://www.linkedin.com/legal/user-agreement?trk=public_profile_v3_desktop_footer-user-agreement)
  * [ Privacy Policy ](https://www.linkedin.com/legal/privacy-policy?trk=public_profile_v3_desktop_footer-privacy-policy)
  * [ Your California Privacy Choices ](https://www.linkedin.com/legal/california-privacy-disclosure?trk=public_profile_v3_desktop_footer-california-privacy-rights-act)
  * [ Cookie Policy ](https://www.linkedin.com/legal/cookie-policy?trk=public_profile_v3_desktop_footer-cookie-policy)
  * [ Copyright Policy ](https://www.linkedin.com/legal/copyright-policy?trk=public_profile_v3_desktop_footer-copyright-policy)
  * [ Brand Policy ](https://brand.linkedin.com/policies?trk=public_profile_v3_desktop_footer-brand-policy)
  * [ Guest Controls ](https://www.linkedin.com/psettings/guest-controls?trk=public_profile_v3_desktop_footer-guest-controls)
  * [ Community Guidelines ](https://www.linkedin.com/legal/professional-community-policies?trk=public_profile_v3_desktop_footer-community-guide)
  *     * العربية (Arabic) 
    * বাংলা (Bangla) 
    * Čeština (Czech) 
    * Dansk (Danish) 
    * Deutsch (German) 
    * Ελληνικά (Greek) 
    * **English (English)**
    * Español (Spanish) 
    * فارسی (Persian) 
    * Suomi (Finnish) 
    * Français (French) 
    * हिंदी (Hindi) 
    * Magyar (Hungarian) 
    * Bahasa Indonesia (Indonesian) 
    * Italiano (Italian) 
    * עברית (Hebrew) 
    * 日本語 (Japanese) 
    * 한국어 (Korean) 
    * मराठी (Marathi) 
    * Bahasa Malaysia (Malay) 
    * Nederlands (Dutch) 
    * Norsk (Norwegian) 
    * ਪੰਜਾਬੀ (Punjabi) 
    * Polski (Polish) 
    * Português (Portuguese) 
    * Română (Romanian) 
    * Русский (Russian) 
    * Svenska (Swedish) 
    * తెలుగు (Telugu) 
    * ภาษาไทย (Thai) 
    * Tagalog (Tagalog) 
    * Türkçe (Turkish) 
    * Українська (Ukrainian) 
    * Tiếng Việt (Vietnamese) 
    * 简体中文 (Chinese (Simplified)) 
    * 正體中文 (Chinese (Traditional)) 
Language 




Agree & Join LinkedIn 

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

`` `` `` `` `` `` ``

##  Message Rishav directly. Skip the cold email. 

Rishav can introduce you to 10+ people at Sprinklr

`` `` `` `` `` `` `` `` `` ``

Email or phone 

Password 

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or 

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=bankarishav&trk=public_profile_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy). 

``